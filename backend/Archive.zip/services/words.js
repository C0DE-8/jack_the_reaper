"use strict";

const crypto = require("crypto");
const db = require("../db");

function parseWords(input) {
  const values = Array.isArray(input)
    ? input
    : String(input || "")
        .split(/[\s,]+/)
        .map((value) => value.trim());

  const words = values
    .map((value) => String(value || "").trim())
    .filter(Boolean);

  if (!words.length) {
    throw new Error("At least one word is required");
  }

  return words;
}

function insertIdFrom(result) {
  if (result && typeof result.insertId !== "undefined") return result.insertId;
  if (Array.isArray(result) && result[0] && typeof result[0].insertId !== "undefined") {
    return result[0].insertId;
  }

  return null;
}

function normalizeTitle(input) {
  const title = String(input || "").trim();
  if (title.length > 255) {
    throw new Error("Title must be 255 characters or less");
  }

  return title || null;
}

function accountNumberFor(batchId) {
  return `JTR-${String(batchId).padStart(6, "0")}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
}

function reviewerNameFrom(reviewer = {}) {
  return reviewer.username
    ? `@${reviewer.username}`
    : [reviewer.firstName || reviewer.first_name, reviewer.lastName || reviewer.last_name].filter(Boolean).join(" ") ||
        reviewer.name ||
        null;
}

function mapAccount(row) {
  if (!row || !row.accountId) return null;

  return {
    id: row.accountId,
    batchId: row.accountBatchId,
    accountNumber: row.accountNumber,
    title: row.accountTitle,
    balances: {
      usdt: Number(row.usdtBalance || 0),
      btc: Number(row.btcBalance || 0),
      eth: Number(row.ethBalance || 0),
      bnb: Number(row.bnbBalance || 0),
      tron: Number(row.tronBalance || 0),
    },
    createdAt: row.accountCreatedAt,
  };
}

function mapBatch(row) {
  if (!row) return null;

  return {
    id: row.id,
    title: row.title,
    source: row.source,
    chatId: row.chatId,
    createdBy: row.createdBy,
    wordCount: Number(row.wordCount || 0),
    approvalStatus: row.approvalStatus || "pending",
    reviewedByChatId: row.reviewedByChatId || null,
    reviewedByName: row.reviewedByName || null,
    reviewedAt: row.reviewedAt || null,
    createdAt: row.createdAt,
    words: row.words || "",
    account: mapAccount(row),
  };
}

async function saveWordBatch({ words, title = null, source, chatId = null, createdBy = null }) {
  const normalizedTitle = normalizeTitle(title);
  const batchResult = await db.execute(
    "INSERT INTO word_batches (title, source, chat_id, created_by, word_count) VALUES (?, ?, ?, ?, ?)",
    [normalizedTitle, source, chatId, createdBy, words.length]
  );
  const batchId = insertIdFrom(batchResult);

  if (!batchId) {
    throw new Error("Could not read word batch insert id");
  }

  const chunkSize = 200;
  for (let index = 0; index < words.length; index += chunkSize) {
    const chunk = words.slice(index, index + chunkSize);
    const placeholders = chunk.map(() => "(?, ?, ?)").join(", ");
    const params = chunk.flatMap((word, chunkIndex) => [batchId, index + chunkIndex + 1, word]);

    await db.execute(
      `INSERT INTO word_batch_items (batch_id, position, word) VALUES ${placeholders}`,
      params
    );
  }

  return {
    id: batchId,
    title: normalizedTitle,
    source,
    chatId,
    createdBy,
    wordCount: words.length,
    approvalStatus: "pending",
    words,
  };
}

function batchSelectSql(whereSql = "") {
  return `
    SELECT
      b.id,
      b.title,
      b.source,
      b.chat_id AS chatId,
      b.created_by AS createdBy,
      b.word_count AS wordCount,
      b.approval_status AS approvalStatus,
      b.reviewed_by_chat_id AS reviewedByChatId,
      b.reviewed_by_name AS reviewedByName,
      b.reviewed_at AS reviewedAt,
      b.created_at AS createdAt,
      GROUP_CONCAT(i.word ORDER BY i.position SEPARATOR ' ') AS words,
      a.id AS accountId,
      a.batch_id AS accountBatchId,
      a.account_number AS accountNumber,
      a.title AS accountTitle,
      a.usdt_balance AS usdtBalance,
      a.btc_balance AS btcBalance,
      a.eth_balance AS ethBalance,
      a.bnb_balance AS bnbBalance,
      a.tron_balance AS tronBalance,
      a.created_at AS accountCreatedAt
    FROM word_batches b
    LEFT JOIN word_batch_items i ON i.batch_id = b.id
    LEFT JOIN word_accounts a ON a.batch_id = b.id
    ${whereSql}
    GROUP BY b.id
  `;
}

async function getWordBatch(batchId) {
  const rows = await db.query(
    `${batchSelectSql("WHERE b.id = ?")}
    LIMIT 1
    `,
    [Number(batchId)]
  );

  return mapBatch(rows[0]);
}

async function listRecentWordBatches(limit = 10) {
  const rows = await db.query(
    `${batchSelectSql()}
    ORDER BY b.created_at DESC
    LIMIT ?
    `,
    [Number(limit) || 10]
  );

  return rows.map(mapBatch);
}

async function createAccountForBatch(batch) {
  await db.execute(
    `
    INSERT INTO word_accounts
      (batch_id, account_number, title, usdt_balance, btc_balance, eth_balance, bnb_balance, tron_balance)
    VALUES (?, ?, ?, 0, 0, 0, 0, 0)
    ON DUPLICATE KEY UPDATE
      title = VALUES(title)
    `,
    [batch.id, accountNumberFor(batch.id), batch.title]
  );
}

async function approveWordBatch(batchId, reviewer = {}) {
  const batch = await getWordBatch(batchId);
  if (!batch) {
    throw new Error("Word batch was not found");
  }
  if (batch.approvalStatus === "rejected") {
    throw new Error("Rejected word batches cannot be approved");
  }

  await createAccountForBatch(batch);
  await db.execute(
    `
    UPDATE word_batches
    SET approval_status = 'approved',
      reviewed_by_chat_id = ?,
      reviewed_by_name = ?,
      reviewed_at = CURRENT_TIMESTAMP
    WHERE id = ?
    `,
    [reviewer.chatId ? String(reviewer.chatId) : null, reviewerNameFrom(reviewer), Number(batchId)]
  );

  return getWordBatch(batchId);
}

async function rejectWordBatch(batchId, reviewer = {}) {
  const batch = await getWordBatch(batchId);
  if (!batch) {
    throw new Error("Word batch was not found");
  }
  if (batch.approvalStatus === "approved") {
    throw new Error("Approved word batches cannot be rejected");
  }

  await db.execute(
    `
    UPDATE word_batches
    SET approval_status = 'rejected',
      reviewed_by_chat_id = ?,
      reviewed_by_name = ?,
      reviewed_at = CURRENT_TIMESTAMP
    WHERE id = ?
    `,
    [reviewer.chatId ? String(reviewer.chatId) : null, reviewerNameFrom(reviewer), Number(batchId)]
  );

  return getWordBatch(batchId);
}

module.exports = {
  approveWordBatch,
  getWordBatch,
  parseWords,
  normalizeTitle,
  rejectWordBatch,
  saveWordBatch,
  listRecentWordBatches,
};
